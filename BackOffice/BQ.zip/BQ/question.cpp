#include "question.h"
#include "ui_question.h"

Question::Question(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Question)
{
    ui->setupUi(this);
}

Question::~Question()
{
    delete ui;
}

void Question::on_Jeu_2_clicked()
{
    this->hide();
    Jeu *jeu = new Jeu();
    jeu->show();
}

void Question::on_Utilisateur_clicked()
{
    this->hide();
    Utilisateur *utilisateur = new Utilisateur();
    utilisateur->show();
}
