#ifndef QUESTION_H
#define QUESTION_H

#include <QDialog>
#include "mainwindow.h"
namespace Ui {
class Question;
}

class Question : public QDialog
{
    Q_OBJECT

public:
    explicit Question(QWidget *parent = 0);
    ~Question();

private slots:
    void on_Jeu_2_clicked();
     void on_Utilisateur_clicked();

private:
    Ui::Question *ui;
};

#endif // QUESTION_H
