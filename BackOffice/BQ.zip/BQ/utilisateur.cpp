#include "utilisateur.h"
#include "ui_utilisateur.h"

Utilisateur::Utilisateur(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Utilisateur)
{
    ui->setupUi(this);
}

Utilisateur::~Utilisateur()
{
    delete ui;
}

void Utilisateur::on_Jeu_2_clicked()
{
    this->hide();
    Jeu *jeu = new Jeu();
    jeu->show();
}

void Utilisateur::on_Question_clicked()
{
    this->hide();
    Theme *theme = new Theme();
    theme->show();
}
