#ifndef MENU_H
#define MENU_H

#include <QDialog>
#include "mainwindow.h"
namespace Ui {
class Menu;
}

class Menu : public QDialog
{
    Q_OBJECT

public:
    explicit Menu(QWidget *parent = 0);
    ~Menu();

private slots:
    void on_Jeu_clicked();

    void on_Question_clicked();

    void on_Utilisateur_clicked();

private:
    Ui::Menu *ui;
    Ui::Menu *menu;
};

#endif // MENU_H
