#include "jeu.h"
#include "ui_jeu.h"

Jeu::Jeu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Jeu)
{
    ui->setupUi(this);
}

Jeu::~Jeu()
{
    delete ui;
}

void Jeu::on_Question_clicked()
{
    this->hide();
    Theme *theme = new Theme();
    theme->show();
}

void Jeu::on_Utilisateur_clicked()
{
    this->hide();
    Utilisateur *utilisateur = new Utilisateur();
    utilisateur->show();
}
