#ifndef JEU_H
#define JEU_H

#include <QDialog>
#include "mainwindow.h"

namespace Ui {
class Jeu;
}

class Jeu : public QDialog
{
    Q_OBJECT

public:
    explicit Jeu(QWidget *parent = 0);
    ~Jeu();

private slots:
    void on_Question_clicked();

    void on_Utilisateur_clicked();

private:
    Ui::Jeu *ui;
    Ui::Jeu *jeu;
};

#endif // JEU_H
