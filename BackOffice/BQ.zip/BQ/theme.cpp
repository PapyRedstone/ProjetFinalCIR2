#include "theme.h"
#include "ui_theme.h"

Theme::Theme(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Theme)
{
    ui->setupUi(this);
}

Theme::~Theme()
{
    delete ui;
}

void Theme::on_Jeu_2_clicked()
{
    this->hide();
    Jeu *jeu = new Jeu();
    jeu->show();
}

void Theme::on_Utilisateur_clicked()
{
    this->hide();
    Utilisateur *utilisateur = new Utilisateur();
    utilisateur->show();
}
