#include "proposition.h"
#include "ui_proposition.h"

Proposition::Proposition(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Proposition)
{
    ui->setupUi(this);
}

Proposition::~Proposition()
{
    delete ui;
}

void Proposition::on_Jeu_2_clicked()
{
    this->hide();
    Jeu *jeu = new Jeu();
    jeu->show();
}

void Proposition::on_Utilisateur_clicked()
{
    this->hide();
    Utilisateur *utilisateur = new Utilisateur();
    utilisateur->show();
}
