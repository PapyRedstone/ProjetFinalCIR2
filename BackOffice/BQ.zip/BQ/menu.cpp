#include "menu.h"
#include "ui_menu.h"

Menu::Menu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Menu)
{
    ui->setupUi(this);
}

Menu::~Menu()
{
    delete ui;
}

void Menu::on_Jeu_clicked()
{
    this->hide();
    Jeu *jeu = new Jeu();
    jeu->show();
}

void Menu::on_Question_clicked()
{
    this->hide();
    Theme *theme = new Theme();
    theme->show();

}

void Menu::on_Utilisateur_clicked()
{
    this->hide();
    Utilisateur *utilisateur = new Utilisateur();
    utilisateur->show();
}
